const x=document.querySelector('.title')

console.log(x.parentNode.parentNode);
console.log(x.childNodes);

